import 'dart:async';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// Servicio para manejar la conexión BLE con el ESP32 + AD8232
class BleService {
  static const String serviceUuid = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
  static const String charUuid = "beb5483e-36e1-4688-b7f5-ea07361b26a8";
  static const String deviceName = "ECG_Monitor";

  BluetoothDevice? _device;
  BluetoothCharacteristic? _characteristic;

  // Stream que emite los datos parseados
  final _dataController = StreamController<EcgData>.broadcast();
  Stream<EcgData> get dataStream => _dataController.stream;

  /// Escanea y conecta al dispositivo ECG_Monitor
  Future<bool> connect() async {
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));

      await for (final results in FlutterBluePlus.scanResults) {
        for (final r in results) {
          if (r.device.platformName == deviceName) {
            await FlutterBluePlus.stopScan();
            _device = r.device;
            await _device!.connect();
            return await _setupCharacteristic();
          }
        }
      }
      return false;
    } catch (e) {
      print('Error al conectar: $e');
      return false;
    }
  }

  Future<bool> _setupCharacteristic() async {
    if (_device == null) return false;

    final services = await _device!.discoverServices();
    for (final service in services) {
      if (service.uuid.toString().toLowerCase() == serviceUuid) {
        for (final c in service.characteristics) {
          if (c.uuid.toString().toLowerCase() == charUuid) {
            _characteristic = c;
            await c.setNotifyValue(true);
            c.lastValueStream.listen((value) {
              final str = String.fromCharCodes(value);
              final data = _parse(str);
              if (data != null) _dataController.add(data);
            });
            return true;
          }
        }
      }
    }
    return false;
  }

  /// Parsea mensajes con formato "ECG:1234,BPM:75,LEAD:ON"
  EcgData? _parse(String message) {
    try {
      final parts = message.split(',');
      int ecg = 0;
      int bpm = 0;
      bool leadOn = true;

      for (final p in parts) {
        final kv = p.split(':');
        if (kv.length != 2) continue;
        switch (kv[0]) {
          case 'ECG':
            ecg = int.tryParse(kv[1]) ?? 0;
            break;
          case 'BPM':
            bpm = int.tryParse(kv[1]) ?? 0;
            break;
          case 'LEAD':
            leadOn = kv[1] == 'ON';
            break;
        }
      }
      return EcgData(ecg: ecg, bpm: bpm, leadOn: leadOn);
    } catch (e) {
      return null;
    }
  }

  Future<void> disconnect() async {
    await _device?.disconnect();
    _device = null;
    _characteristic = null;
  }

  void dispose() {
    _dataController.close();
  }
}

class EcgData {
  final int ecg;
  final int bpm;
  final bool leadOn;
  EcgData({required this.ecg, required this.bpm, required this.leadOn});
}
