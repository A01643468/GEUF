import 'dart:async';
import 'dart:convert';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

/// Servicio para conectarse al HC-05 por Bluetooth Clasico (SPP)
class BluetoothService {
  BluetoothConnection? _connection;
  String _buffer = '';

  final _dataController = StreamController<EcgData>.broadcast();
  Stream<EcgData> get dataStream => _dataController.stream;

  bool get isConnected => _connection?.isConnected ?? false;

  /// Lista los dispositivos ya emparejados con el telefono
  Future<List<BluetoothDevice>> getPairedDevices() async {
    return await FlutterBluetoothSerial.instance.getBondedDevices();
  }

  /// Conecta a un dispositivo por su direccion MAC
  Future<bool> connect(String address) async {
    try {
      _connection = await BluetoothConnection.toAddress(address);

      _connection!.input!.listen((data) {
        _buffer += utf8.decode(data, allowMalformed: true);

        // Procesar mensajes completos (terminados en \n)
        while (_buffer.contains('\n')) {
          final idx = _buffer.indexOf('\n');
          final line = _buffer.substring(0, idx).trim();
          _buffer = _buffer.substring(idx + 1);

          final parsed = _parse(line);
          if (parsed != null) _dataController.add(parsed);
        }
      }).onDone(() {
        print('Desconectado del HC-05');
      });

      return true;
    } catch (e) {
      print('Error al conectar: $e');
      return false;
    }
  }

  /// Parsea "ECG:1234,BPM:75,LEAD:ON"
  EcgData? _parse(String message) {
    try {
      final parts = message.split(',');
      int ecg = 0;
      int bpm = 0;
      bool leadOn = true;

      for (final p in parts) {
        final kv = p.split(':');
        if (kv.length != 2) continue;
        switch (kv[0]) {
          case 'ECG':
            ecg = int.tryParse(kv[1]) ?? 0;
            break;
          case 'BPM':
            bpm = int.tryParse(kv[1]) ?? 0;
            break;
          case 'LEAD':
            leadOn = kv[1] == 'ON';
            break;
        }
      }
      return EcgData(ecg: ecg, bpm: bpm, leadOn: leadOn);
    } catch (e) {
      return null;
    }
  }

  Future<void> disconnect() async {
    await _connection?.close();
    _connection = null;
  }

  void dispose() {
    _connection?.dispose();
    _dataController.close();
  }
}

class EcgData {
  final int ecg;
  final int bpm;
  final bool leadOn;
  EcgData({required this.ecg, required this.bpm, required this.leadOn});
}
