# flutter_app/ – Carpeta de ensamble

Esta carpeta contiene el proyecto Flutter listo para compilar. Los archivos `.dart` de cada integrante se copian aquí desde sus carpetas individuales.

## Cómo ensamblar

### Opción A: con script (Linux/Mac)

Desde la raíz del repo:

```bash
bash docs/ensamblar.sh
```

### Opción B: con script (Windows)

```bash
docs\ensamblar.bat
```

### Opción C: manualmente

Copia estos archivos a `flutter_app/lib/`:

| Desde | Archivo |
|---|---|
| `integrante2_comunicacion/` | `data_source.dart` |
| `integrante2_comunicacion/` | `demo_source.dart` |
| `integrante2_comunicacion/` | `bluetooth_source.dart` |
| `integrante3_ui/` | `main.dart` |
| `integrante3_ui/` | `home_screen.dart` |
| `integrante3_ui/` | `profile_screen.dart` |
| `integrante4_logica/` | `recommendation.dart` |

## Después de ensamblar

```bash
cd flutter_app
flutter pub get
flutter run
```

## Importante

**No editen archivos directamente en `flutter_app/lib/`**. Editen siempre en la carpeta del integrante correspondiente y vuelvan a ensamblar. Esto mantiene claras las contribuciones de cada quien.
