/*
 * ECG Monitor con AD8232 + ESP32 + BLE
 * 
 * Pinout AD8232 -> ESP32:
 *   OUTPUT  -> GPIO 34 (ADC)
 *   LO+     -> GPIO 32
 *   LO-     -> GPIO 33
 *   3.3V    -> 3.3V
 *   GND     -> GND
 * 
 * Envía por BLE:
 *   - Valor de la señal ECG (cada ~10ms)
 *   - BPM calculado (cada segundo)
 */

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// UUIDs del servicio BLE
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

// Pines
#define ECG_PIN 34
#define LO_PLUS 32
#define LO_MINUS 33

BLECharacteristic *pCharacteristic;
bool deviceConnected = false;

// Variables para cálculo de BPM
unsigned long lastBeat = 0;
unsigned long beatIntervals[5] = {0, 0, 0, 0, 0};
int beatIndex = 0;
int bpm = 0;
int threshold = 2000;  // Umbral para detectar pico R (ajustar según señal)
bool aboveThreshold = false;

class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("Cliente conectado");
    }
    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("Cliente desconectado");
      pServer->startAdvertising();
    }
};

void setup() {
  Serial.begin(115200);
  
  pinMode(LO_PLUS, INPUT);
  pinMode(LO_MINUS, INPUT);
  
  // Configurar BLE
  BLEDevice::init("ECG_Monitor");
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  
  BLEService *pService = pServer->createService(SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(
                      CHARACTERISTIC_UUID,
                      BLECharacteristic::PROPERTY_NOTIFY
                    );
  pCharacteristic->addDescriptor(new BLE2902());
  
  pService->start();
  pServer->getAdvertising()->start();
  Serial.println("Esperando conexion BLE...");
}

void loop() {
  // Verificar si los electrodos están conectados
  if ((digitalRead(LO_PLUS) == 1) || (digitalRead(LO_MINUS) == 1)) {
    if (deviceConnected) {
      String msg = "ECG:0,BPM:0,LEAD:OFF";
      pCharacteristic->setValue(msg.c_str());
      pCharacteristic->notify();
    }
    delay(100);
    return;
  }
  
  int ecgValue = analogRead(ECG_PIN);
  
  // Detección simple de pico R para calcular BPM
  if (ecgValue > threshold && !aboveThreshold) {
    aboveThreshold = true;
    unsigned long now = millis();
    if (lastBeat > 0) {
      unsigned long interval = now - lastBeat;
      if (interval > 300 && interval < 2000) {  // Filtrar ruido (30-200 BPM)
        beatIntervals[beatIndex] = interval;
        beatIndex = (beatIndex + 1) % 5;
        
        // Promedio de los últimos 5 intervalos
        unsigned long sum = 0;
        int count = 0;
        for (int i = 0; i < 5; i++) {
          if (beatIntervals[i] > 0) {
            sum += beatIntervals[i];
            count++;
          }
        }
        if (count > 0) bpm = 60000 / (sum / count);
      }
    }
    lastBeat = now;
  } else if (ecgValue < threshold) {
    aboveThreshold = false;
  }
  
  // Enviar datos por BLE
  if (deviceConnected) {
    String msg = "ECG:" + String(ecgValue) + ",BPM:" + String(bpm) + ",LEAD:ON";
    pCharacteristic->setValue(msg.c_str());
    pCharacteristic->notify();
  }
  
  delay(10);  // ~100 Hz de muestreo
}
